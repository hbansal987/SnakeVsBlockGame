package application;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author Himanshu Bansal
 * has information about the leaderboard of the game. Implements comparable and serializable
 */
public class LeaderBoard implements Serializable, Comparable<LeaderBoard> {
	private static final long serialVersionUID = 1L;
	String name;
	int score;
	Date date;
	String dateString;

	/**
	 * @param nameS the name of the player
	 * @param scoreS score of the player
	 * constructor for the leaderboard. Takes the name and score as variables
	 */
	public LeaderBoard(String nameS, int scoreS) {
		name = (nameS);
		score = (scoreS);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
		date = new Date();
		dateString = ((dateFormat.format(date))); // 2016/11/16 12:08:43
	}

	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 * Comapre to method to get different scores.
	 */
	@Override
	public int compareTo(LeaderBoard arg0) {
		// TODO Auto-generated method stub
		if(this.score != arg0.score) {
			return arg0.score - this.score;
		}else {
			if(this.date.before(arg0.date)) {
				return -1;
			}else {
				return 1;
			}
		}
	}

}

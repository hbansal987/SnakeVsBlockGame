package application;

import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

/**
 * @author Himanshu Bansal
 * This controls the formation of the smalls particles formed during the collsion of snake with the block.
 */
public class particle {
	Circle c;
	int animations;
	double speedX;
	double speedY;
	boolean shouldDie = false;
	int maxAnimations = 60;
	
	/**
	 * @param cc the particle
	 * @param xx x position
	 * @param yy y position
	 * constructor for the particle class. Gives the paticles its shape and position
	 */
	public particle(Circle cc,double xx,double yy) {
		animations = 0;
		speedX = xx;
		speedY = yy;
//		System.out.println(xx + "," + yy);
		c = cc;
//		cc.setRadius(30);
//		cc.setOpacity(0.05);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * Go generate an output
	 */
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		String s = "" + speedX + " " + speedY;
		return s;
	}
	
	/**
	 * generates animation for the blasting effect
	 */
	public void animate() {
		if(animations > maxAnimations) {
//			System.out.println("ready to die");
			shouldDie = true;
		}else {
			animations++;
			c.setCenterX(c.getCenterX() + speedX);
			c.setCenterY(c.getCenterY() + speedY);
			speedY -= -0.05;
		}
	}
}

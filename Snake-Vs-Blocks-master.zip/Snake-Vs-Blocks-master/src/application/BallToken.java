package application;

import java.io.Serializable;
import java.util.Random;

import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * @author Himanshu Bansal 
 * This is the token class for the ball tokens. It extends the Token class
 */
public class BallToken extends Token implements Serializable{

	
	private int frequency = 4;
	private ImageView picture;
	
	/* (non-Javadoc)
	 * @see application.Token#SetPhoto(javafx.scene.image.ImageView)
	 * Sets the particular photo for different token
	 */
	public void SetPhoto(ImageView picture) {
		this.picture= picture;
	}
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public void Power() {	
	}
	public ImageView getPicture() {
		return picture;
	}
	
	
	/* (non-Javadoc)
	 * @see application.Token#setPicture(javafx.scene.image.ImageView)
	 * makes the picture varible for the ball class
	 */
	public void setPicture(ImageView picture) {
		this.picture = picture;
		this.picture.setFitHeight(40);
		this.picture.setFitWidth(40);
		Random rand= new Random();
		int v= rand.nextInt(5)+1;
		this.setBall_value(v);
		this.setBall_label(new Label(Integer.toString(this.getBall_value())));
		
	}
}

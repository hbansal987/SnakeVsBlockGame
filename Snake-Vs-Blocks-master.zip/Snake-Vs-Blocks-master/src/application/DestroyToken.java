package application;

import java.io.Serializable;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * @author Himanshu Bansal
 * had the information about the Destroy Token
 */
public class DestroyToken extends Token implements Serializable{
//	public DestroyToken(ImageView pic) {
//		super(pic);
//		// TODO Auto-generated constructor stub
//	}
	private int frequency = 1;
	private ImageView picture;
	
	/* (non-Javadoc)
	 * @see application.Token#SetPhoto(javafx.scene.image.ImageView)
	 * Sets the photo for the token
	 */
	public void SetPhoto(ImageView picture) {
		this.picture= picture;
	}
	
	public int getFrequency() {
		return frequency;
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public void Power() {
		
	}
	public ImageView getPicture() {
		return picture;
	}
	/* (non-Javadoc)
	 * @see application.Token#setPicture(javafx.scene.image.ImageView)
	 * Sets the image for the token
	 */
	public void setPicture(ImageView picture) {
		this.picture = picture;
		this.picture.setFitHeight(40);
		this.picture.setFitWidth(40);
	}
}

package application;

import java.io.Serializable;

import javafx.animation.PathTransition;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

/**
 * @author Himanshu Bansal
 * Has all the information about the Token. It is the abstract class. This is extended by the different token.
 */
public abstract class Token implements Serializable{
	private int positionX; 
	private int positionY;
	private ImageView picture;
	private int isCollide=0;
	private Label ball_label;
	private PathTransition transition;
	private PathTransition transition2;
	private int ball_value;
	public double speed;
	public String name;
	
	public PathTransition getTransition2() {
		return transition2;
	}
	public void setTransition2(PathTransition transition2) {
		this.transition2 = transition2;
	}
	public PathTransition getTransition() {
		return transition;
	}
	public void setTransition(PathTransition transition) {
		this.transition = transition;
	}
	public Label getBall_label() {
		return ball_label;
	}
	public void setBall_label(Label ball_label) {
		this.ball_label = ball_label;
	}
	public int getBall_value() {
		return ball_value;
	}
	public void setBall_value(int ball_value) {
		this.ball_value = ball_value;
	}
	
	/**
	 * These are the abstract methods that are overriden in diffent types of token
	 */
	public abstract void Power();
	public abstract void SetPhoto(ImageView picture);
	
	public int getIsCollide() {
		return isCollide;
	}
	public void setIsCollide(int isCollide) {
		this.isCollide = isCollide;
	}
	public ImageView getPicture() {
		return picture;
	}
	/**
	 * @param picture the image of token
	 * Sets the image of the Token
	 */
	public void setPicture(ImageView picture) {
		this.picture = picture;
		this.picture.setFitHeight(40);
		this.picture.setFitWidth(40);
	}
	public int getPositionX() {
		return positionX;
	}
	public void setPositionX(int positionX) {
		this.positionX = positionX;
	}
	public int getPositionY() {
		return positionY;
	}
	public void setPositionY(int positionY) {
		this.positionY = positionY;
	}
}

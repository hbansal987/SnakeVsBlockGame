package application;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.LinkedList;

import javafx.animation.AnimationTimer;
import javafx.scene.layout.Pane;
import javafx.scene.media.MediaPlayer;

/**
 * @author Himanshu Bansal
 * This class has information about all the varibales of the games. Stores their information ar all times.
 */
public class GameState implements Serializable {
	/**
	 * Different private variables used 
	 */
	private static final long serialVersionUID = 1L;
	private ArrayList<Wall> wall_arr;
	private Snake snake;
	private ArrayList<Token> token_arr;
	private ArrayList<Block> block_arr;
	private int score;
	
	Game g;
	
	public static int flag=-5;
	
	public Pane pane;
	public static AnimationTimer timer;
	public static int index2=0;
	public static int ShieldOn=0;
	public int old_timer;
	public int old_timer2;
	public int count2=0;
	public int isResume=0;
	public int blockOn=0;
	public int flagWall=0;
	public int magnetOn=0;
	public int t;
	public int ON=0;
	public int last_score=0;
	
	MediaPlayer mp;
	LinkedList<particle> particles = new LinkedList<>();
	
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}
	
	public ArrayList<Wall> getWall_arr() {
		return wall_arr;
	}

	public void setWall_arr(ArrayList<Wall> wall_arr) {
		this.wall_arr = wall_arr;
	}

	public Snake getSnake() {
		return snake;
	}

	public void setSnake(Snake snake) {
		this.snake = snake;
	}

	public ArrayList<Block> getBlock_arr() {
		return block_arr;
	}

	public void setBlock_arr(ArrayList<Block> block_arr) {
		this.block_arr = block_arr;
	}

	public ArrayList<Token> getToken_arr() {
		return token_arr;
	}

	public void setToken_arr(ArrayList<Token> token_arr) {
		this.token_arr = token_arr;
	}

	/**
	 * @param g the main Game
	 * Contructor for the gameState class... initializes all the arrays that are used to store the state.
	 */
	public GameState(Game g) {
		this.g = g;
		wall_arr= new ArrayList<Wall>();
		snake= new Snake(this);
		block_arr= new ArrayList<Block>();
		token_arr= new ArrayList<Token>();
	}
	
}

package application;

import java.io.Serializable;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 * @author Himanshu Bansal
 * Has the information about the magnet token. It is extended by the Token Class.
 */
public class MagnetToken extends Token implements Serializable{
//	public MagnetToken(ImageView pic) {
//		super(pic);
//		// TODO Auto-generated constructor stub
//	}
	private int frequency = 1;
	private ImageView picture;
	
	/* (non-Javadoc)
	 * @see application.Token#SetPhoto(javafx.scene.image.ImageView)
	 * Sets a different photo for the the token
	 */
	public void SetPhoto(ImageView picture) {
		this.picture= picture;
	}
	
	public int getFrequency() {
		return frequency;
	}
	public void Power() {
		
	}
	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}
	public ImageView getPicture() {
		return picture;
	}
	/* (non-Javadoc)
	 * @see application.Token#setPicture(javafx.scene.image.ImageView)
	 * Sets the image for the token
	 */
	public void setPicture(ImageView picture) {
		this.picture = picture;
		this.picture.setFitHeight(40);
		this.picture.setFitWidth(40);
	}
}

package application;


import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Optional;
import java.util.Random;

//import blastGame.particle;
import javafx.scene.Scene;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;

/**
 * @author Himanshu Bansal
 * Has all the information about the snake in the game. Has a snake array which has all the length of the snake. 
 */
public class Snake implements Serializable {
	/**
	 * Diferent private and public varibales used by the snake class
	 */
	GameState gs;
	private static final long serialVersionUID = 1L;
	private double positionX; // assign center screen horizontally
	private double positionY; // assign apprporiate value here
	private int length;
	private Circle picture;
	private ArrayList<Circle> snake_arr = new ArrayList<Circle>();
	public double time;
	public int value = 0;
	int prevScore = -1;

	int snakeRadius = 10;

	/**
	 * @param gssss the main gamestate
	 * constructor for snake class. Initializes it and gives it a length
	 */
	public Snake(GameState gssss) {
		gs = gssss;
		length = 4;
	}

	public ArrayList<Circle> getSnake_arr() {
		return snake_arr;
	}

	public void setSnake_arr(ArrayList<Circle> snake_arr) {
		this.snake_arr = snake_arr;
	}

	public int getLength() {
		return length;
	}

	public Circle getPicture() {
		return picture;
	}

	public void setPicture(Circle picture) {
		this.picture = picture;
	}

	public double getPositionX() {
		return positionX;
	}

	public void setPositionX(double d) {
		this.positionX = d;
	}

	public double getPositionY() {
		return positionY;
	}

	public void setPositionY(double d) {
		this.positionY = d;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public void collisionWithWall(Wall w) {

	}
	
	/**
	 * @param pane the main layout
	 * @param b the block 
	 * @param gameState gamestate
	 * @param primaryStage the main stage
	 * @param scene_game the main scene
	 * This is called when there is a collision with the block. It takes care of reducing the lenth and also checks that the snake has died or not
	 */
	public void collisionWithBlock(Pane pane, Block b, GameState gameState, Stage primaryStage, Scene scene_game) {

		// System.out.println("Hello");
		if (b.blown  == 0) {
			if (value == 0) {
				gameState.setScore(gameState.getScore() + b.getBlockVal());
				Game.score_label.setText("score= " + gameState.getScore());
			}
			if (gameState.ShieldOn == 0) {
				if (value == 0) {
					setLength(getLength() - b.getBlockVal());
					Game.length_label.setText("Length= " + getLength());
					value = 1;
				}
				int length = getSnake_arr().size();

				if(b.getBlockVal() >= 5) {
				pauseAll(gameState);

				for (int w = 0; w < b.getBlockVal(); w++) {
					pane.getChildren().remove(getSnake_arr().get(length - 1 - w));
					// ADD ANOTHER KIND OF BLAST FOR SNAKE HERE
					createBlastParticles(5 ,10, getSnake_arr().get(0).getFill() ,  getSnake_arr().get(0).getCenterX() ,  getSnake_arr().get(0).getCenterY(), pane);
					getSnake_arr().remove(length - 1 - w);
					setPositionY(getPositionY() - 20);
					b.setBlockVal(b.getBlockVal() - 1);
					b.getValue().setText(Integer.toString(b.getBlockVal()));
					b.updateColor();
					time = System.currentTimeMillis();

					if (snakeDied(gameState, primaryStage, scene_game)) {
						break;
					}
					while (System.currentTimeMillis() - time < 30) {
					}
					gameState.blockOn = 1;
					return;
				}
				}
				else {
					for (int w = 0; w < b.getBlockVal(); w++) {
						System.out.println(w);
						length = getSnake_arr().size();
						pane.getChildren().remove(getSnake_arr().get(length - 1));
						// ADD ANOTHER KIND OF BLAST FOR SNAKE HERE
						createBlastParticles(5 ,10, getSnake_arr().get(0).getFill() ,  getSnake_arr().get(0).getCenterX() ,  getSnake_arr().get(0).getCenterY(), pane);
						getSnake_arr().remove(length - 1);
						setPositionY(getPositionY() - 20);
						b.updateColor();
						time = System.currentTimeMillis();
						gameState.blockOn=1;
						if (snakeDied(gameState, primaryStage, scene_game)) {
							
							PrintWriter writer = null;
							try {
								writer = new PrintWriter("blockinfo.txt");
							} catch (FileNotFoundException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							writer.print("");
							writer.close();
							Game.root.getChildren().remove(Game.resumeGame);
							break;
						}
					}
					
				}

				try {
				for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
					gameState.getBlock_arr().get(r).getTransition1().play();
					gameState.getBlock_arr().get(r).getTransition2().play();
				}

				for (int r = 0; r < gameState.getToken_arr().size(); r++) {
					gameState.getToken_arr().get(r).getTransition().play();
					if (gameState.getToken_arr().get(r).getTransition2() != null) {
						gameState.getToken_arr().get(r).getTransition2().play();
					}
				}

				for (int r = 0; r < gameState.getWall_arr().size(); r++) {
					gameState.getWall_arr().get(r).getTransition2().play();
				}
				}
				catch(Exception e) {
					
				}
			}else {
				
			}
			b.blown = (1);
			burstBlock(b, pane);
		}
		gameState.blockOn = 0;
		value = 0;
	}
	
	/**
	 * @param paint the color
	 * @param mouseX positionx
	 * @param mouseY positiony
	 * @param pane the main layout
	 * This created the small blast particles that are generated during collision
	 */
	private void createBlastParticles(Paint paint, double mouseX, double mouseY, Pane pane) {
		// TODO Auto-generated method stub
//		System.out.println("create explosion");
		mouseX +=50;
		mouseY +=50;
		for (int i = 0; i < 200; i++) {
			Random rand = new Random();
			Circle c = new Circle(mouseX + (((double) (rand.nextInt(40)) - 21)),
					mouseY + (((double) (rand.nextInt(40)) - 21)), 2);
			c.setFill(paint);
			double speedX = ((double) (rand.nextInt(100)) - 50) / 50;
			double speedY = ((double) (rand.nextInt(100)) - 50) / 50;
			gs.particles.add(new particle(c, speedX, speedY));
			pane.getChildren().add(gs.particles.getLast().c);
		}
	}
	
	/**
	 * @param count variable
	 * @param max no. of small particles
	 * @param paint colour
	 * @param mouseX positionx
	 * @param mouseY positiony
	 * @param pane the main layout
	 * This created the small blast particles that are generated during collision
	 */
	private void createBlastParticles(int count , int max, Paint paint, double mouseX, double mouseY, Pane pane) {
		// TODO Auto-generated method stub
//		System.out.println("create explosion");
//		mouseX +=50;
//		mouseY +=50;
		for (int i = 0; i < count; i++) {
			Random rand = new Random();
			Circle c = new Circle(mouseX + (((double) (rand.nextInt(40)) - 21)),
					mouseY + (((double) (rand.nextInt(40)) - 21)), 2);
			c.setFill(paint);
			double speedX = ((double) (rand.nextInt(100)) - 50) / 50;
			double speedY = ((double) (rand.nextInt(100)) - 50) / 50;
			gs.particles.add(new particle(c, speedX, speedY));
			gs.particles.getLast().maxAnimations = max;
			pane.getChildren().add(gs.particles.getLast().c);
		}
	}
	
	/**
	 * @param gameState the gamestate
	 * @param primaryStage the main stage
	 * @param scene_game the main scene
	 * @return
	 * Checks that the snake has died or not. also clear all the arrays and saves the state.
	 */
	public boolean snakeDied(GameState gameState, Stage primaryStage, Scene scene_game) {
		if (getSnake_arr().size() <= 0) {
		prevScore = gameState.getScore();
		gameState.last_score=gameState.getScore();
		//System.out.println("bansal= "+gameState.last_score);
		gameState.timer.stop();
		gameState.setScore(0);
		gameState.getBlock_arr().clear();
		gameState.getToken_arr().clear();
		gameState.flag = -5;
		gameState.index2 = 0;
		primaryStage.setScene(scene_game);
		Game.lastscore.setText("Previous Score: "+ gameState.last_score);
		Game.highscore.setText("High Score: "+ Game.ranks.get(0).score);
		gameState.mp.stop();
		return true;
		}else {
			return false;
		}
	}

	/**
	 * @param b the block with which we collide
	 * @param pane teh main layout
	 * generates the burst blocks during the collision
	 */
	private void burstBlock(Block b, Pane pane) {
		// TODO Auto-generated method stub
		pane.getChildren().remove(b.getShape());
		pane.getChildren().remove(b.getValue());
		createBlastParticles(b.getShape().getFill() , b.getShape().getTranslateX(), b.getShape().getTranslateY(), pane);
	}

	/**
	 * @param gameState the gamestate
	 * pauses the state during collision. The Path Transition is stopped.
	 */
	private void pauseAll(GameState gameState) {
		// TODO Auto-generated method stub
		for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
			//System.out.println("gameState.getBlock_arr().size= "+ gameState.getBlock_arr().size());
			gameState.getBlock_arr().get(r).getTransition1().pause();
			gameState.getBlock_arr().get(r).getTransition2().pause();
		}

		for (int r = 0; r < gameState.getToken_arr().size(); r++) {
			gameState.getToken_arr().get(r).getTransition().pause();
			if (gameState.getToken_arr().get(r).getTransition2() != null) {
				gameState.getToken_arr().get(r).getTransition2().pause();
			}
		}

		for (int r = 0; r < gameState.getWall_arr().size(); r++) {
			gameState.getWall_arr().get(r).getTransition2().pause();
		}

	}

	public void increaseLength(int amt) {

	}

	public void usePower(Token token) {

	}

	public void display() {

	}

	/**
	 * @param pane the main layout 
	 * makes the snake
	 */
	public void makeSnake(Pane pane) {
		setPositionX(250);
		setPositionY(710);
		int snakeRadius = 10;

		for (int k = 0; k < 4; k++) {
			getSnake_arr().add(new Circle(250, 650 + (snakeRadius + snakeRadius) * k, snakeRadius));
			getSnake_arr().get(k).setFill(Color.WHITE);
			pane.getChildren().add(getSnake_arr().get(k));
		}
	}
}

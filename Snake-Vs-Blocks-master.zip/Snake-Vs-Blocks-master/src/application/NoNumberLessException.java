package application;

/**
 * @author Himanshu Bansal
 * Exception generated when no number is less than the snake length in the block chain.
 */
public class NoNumberLessException extends Exception {

	public NoNumberLessException(String message) {
		super(message);
	}
}


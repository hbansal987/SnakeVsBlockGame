package bonusGame;

import java.util.LinkedList;
import java.util.Random;

import application.Game;
import application.GameState;
import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class screen extends Application {
	Player p;
	LinkedList<Path> route = new LinkedList<>();
	LinkedList<Fire> fires = new LinkedList<>();
	LinkedList<Coin> coins = new LinkedList<>();
	Pane pane;
	Scene bonusScene;
	AnimationTimer timer2;
	public int on = 2;
	public int off=0;

	public static void main(String[] args) {
		launch(args);
	}

	public void start2(Stage primaryStage,GameState gameState) throws Exception {
		pane = new Pane();
		bonusScene = new Scene(pane, 500, 800);
		p = new Player(bonusScene);
		primaryStage.setScene(bonusScene);
		primaryStage.show();

		timer2 = new AnimationTimer() {
			@Override
			public void handle(long now) {
				handleFire();
				checkFlames(primaryStage,gameState);
				checkCoins(gameState);
			}
		};
		timer2.start();

		bonusScene.setFill(Color.BLACK);
		bonusScene.setOnKeyPressed(e -> {
			if (e.getCode() == KeyCode.LEFT) {
				System.out.println("Press left");
				moveLeft();
			} else if (e.getCode() == KeyCode.RIGHT) {
				System.out.println("Press Right");
				moveRight();
			} else if (e.getCode() == KeyCode.UP) {
				System.out.println("Press Up");
				moveUp(primaryStage,gameState);
			} else if (e.getCode() == KeyCode.DOWN) {
				System.out.println("Press Down");
				moveDown();
			} else {

			}
		});
		spawnRoute(bonusScene);
		pane.getChildren().add(p.c);
	}

	protected void checkCoins(GameState gameState) {
		for (Coin d : coins) {
			if (isColliding(p.c, d.c) && d.alive) {
				getPaid(d,gameState);
			}
		}
	}

	private void getPaid(Coin d, GameState gameState) {
		p.score += d.value;
		System.out.println(p.score);
		gameState.setScore(gameState.getScore()+10);
		d.spent(pane);
	}

	protected void checkFlames(Stage primaryStage,GameState gameState) {
		for (Fire f : fires) {
			if (isColliding(p.c, f.c) && f.flameOn) {
				getBurnt(f,primaryStage,gameState);
				return;
			}
		}
	}

	private void getBurnt(Fire f,Stage primaryStage,GameState gameState) {
		// TODO end game in different format
		System.out.println("just got burnt");
		gameState.timer.start();
		timer2.stop();
		off=1;
		primaryStage.close();
		return;
	}

	protected void handleFire() {
		for (Fire f : fires) {
			f.updateFire();
		}
	}

	private boolean pathExists() {
		for (Path router : route) {
			if (isColliding(p.c, router.square)) {
				return true;
			}
		}
		return false;
	}

	private void moveDown() {
		if (p.canMoveDown()) {
			p.moveDown();
			if (!pathExists()) {
				p.moveUp();
			}
		}
	}

	private void moveUp(Stage primaryStage, GameState gameState) {
		if (p.reachedScreenEnd()) {
			exitGame(primaryStage, gameState);
		} else if (p.canMoveUp()) {
			p.moveUp();
			if (!pathExists()) {
				p.moveDown();
			}
		}

	}

	private void exitGame(Stage primaryStage, GameState gameState) {
		System.out.println("reached top");
		timer2.stop();
		for (int r = 0; r < gameState.getBlock_arr().size(); r++) {
			gameState.getBlock_arr().get(r).getTransition1().play();
			gameState.getBlock_arr().get(r).getTransition2().play();
		}

		for (int r = 0; r < gameState.getToken_arr().size(); r++) {
			gameState.getToken_arr().get(r).getTransition().play();
			if (gameState.getToken_arr().get(r).getTransition2() != null) {
				gameState.getToken_arr().get(r).getTransition2().play();
			}
		}

		for (int r = 0; r < gameState.getWall_arr().size(); r++) {
			gameState.getWall_arr().get(r).getTransition2().play();
		}
		gameState.timer.start();
		
		
		
		primaryStage.close();
		p.c.setVisible(false);
		// TODO exit game
	}

	private void moveRight() {
		if (p.canMoveRight()) {
			p.moveRight();
			if (!pathExists()) {
				p.moveLeft();
			}
		}
	}

	private void moveLeft() {
		if (p.canMoveLeft()) {
			p.moveLeft();
			if (!pathExists()) {
				p.moveRight();
			}
		}
	}

	private void spawnRoute(Scene s) {
		double height = s.getHeight();
		double width = s.getWidth();
		createPath(width/2, height - 50 );
		while (true) {
			Path currPath = route.getLast();
			if (currPath.reachedTop()) {
				break;
			} else {
				Random rand = new Random();
				int chosen = rand.nextInt(9) + 1;
				if (chosen <= 3 && currPath.canLeft() == 1) {
					Path leftPath = new Path(currPath.centerX - 100, currPath.centerY, bonusScene);
					if (!pathExists(leftPath)) {
						createPath(leftPath);
						assignFireCoin(leftPath);
					}
				} else if (chosen <= 6 && currPath.canRight() == 1) {
					Path rightPath = new Path(currPath.centerX + 100, currPath.centerY, bonusScene);
					if (!pathExists(rightPath)) {
						createPath(rightPath);
						assignFireCoin(rightPath);
					}
				} else {
					Path forwardPath = new Path(currPath.centerX, currPath.centerY - 100, bonusScene);
					createPath(forwardPath);
					assignFireCoin(forwardPath);
				}
			}
		}
	}

	public void createPath(double a, double b) {
		createPath(new Path(a, b, bonusScene));
	}

	public void createPath(Path p) {
		route.add(p);
		pane.getChildren().add(route.getLast().square);
	}

	public boolean pathExists(Path p2) {
		for (Path p : route)
			if (p.equals(p2))
				return true;
		return false;
	}

	public void assignFireCoin(Path p) {
		Random rand = new Random();
		double val = rand.nextFloat();
		if (val < 0.4) {
			// empty
		} else if (val < 0.75) {
			// coin
			spawnCoin(p);
		} else {
			// fire
			spawnFire(p);
		}
	}

	private void spawnFire(Path p2) {
		fires.add(new Fire(p2, pane));
		pane.getChildren().add(fires.getLast().c);
	}

	private void spawnCoin(Path p2) {
		coins.add(new Coin(p2));
		pane.getChildren().add(coins.getLast().c);
	}

	public boolean isColliding(Circle c, Rectangle r) {
		return c.getBoundsInParent().intersects(r.getBoundsInParent());
	}

	public boolean isColliding(Circle c, Circle r) {
		return c.getBoundsInParent().intersects(r.getBoundsInParent());
	}

	private boolean isColliding(Circle c, ImageView c2) {
		return c.getBoundsInParent().intersects(c2.getBoundsInParent());
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
	}
}

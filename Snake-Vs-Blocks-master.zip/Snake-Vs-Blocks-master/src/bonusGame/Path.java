package bonusGame;

import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
//500 * 800;
public class Path {
	double sceneH;
	double sceneW;
	Rectangle square;
	double centerX;
	double centerY;
	double size = 100;
	
	Path(double cx, double cy, Scene s) {
		sceneH = s.getHeight();
		sceneW = s.getWidth();
		
		centerX = cx;
		centerY = cy;
		square = new Rectangle();
		square.setTranslateX(centerX - 50);
		square.setTranslateY(centerY - 50);
		square.setHeight(100);
		square.setWidth(100);
		square.setFill(Color.BROWN);
	}
	
	boolean equals(Path other) {
		if(this.centerX == other.centerX && this.centerY == other.centerY ) {
			return true;
		}else {
			return false;
		}
	}
	
	public int canLeft() {
		if(centerX - 100 > 0) {
			return 1;
		}else {
			return 0;
		}
	}
	
	public int canRight() {
		if(centerX + 100 < sceneW ) {
			return 1;
		}else {
			return 0;
		}
	}
	
	public boolean reachedTop() {
		return (centerY - 100 < 0);
	}
}

package bonusGame;

import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Player {
	Circle c;
	double positionx;
	double positiony;
	int score = 0;
	double sceneH;
	double sceneW;

	Player(Scene s) {
		sceneH = s.getHeight();
		sceneW = s.getWidth();
		System.out.println("player constructor");
		positionx = sceneW/2;
		positiony = sceneH  -50 ;
		c = new Circle(positionx, positiony, 30);
		c.setFill(Color.PINK);
	}

	public boolean canMoveLeft() {
		return (positionx - 100 > 0);
	}

	public boolean canMoveRight() {
		return (positionx + 100 < sceneW);
	}

	public boolean canMoveUp() {
		return (positiony - 100 > 0);
	}
	
	public boolean reachedScreenEnd() {
		return (positiony - 100  < 0);
	}

	public boolean canMoveDown() {
		return (positiony + 100 < sceneH);
	}

	public void moveLeft() {
		positionx -= 100;
		c.setCenterX(positionx);
	}
	
	public void moveRight() {
		positionx += 100;
		c.setCenterX(positionx);
	}
	
	public void moveUp() {
		positiony -= 100;
		System.out.println("y: " +positiony);
		c.setCenterY(positiony);
	}
	
	public void moveDown() {
		positiony += 100;
		c.setCenterY(positiony);
	}
}

package bonusGame;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class Coin {
	ImageView c;
	double positionx;
	double positiony;
	int value;
	boolean alive = true;

	public Coin(Path p2) {
		// TODO Auto-generated constructor stub
		positionx = p2.centerX;
		positiony = p2.centerY;

		Image fireImage = new Image("/bonusGame/coin.gif");
		c = new ImageView();
		c.setImage(fireImage);
		c.setFitHeight(100);
		c.setFitWidth(100);
		c.setX(p2.centerX - 50);
		c.setY(p2.centerY - 50);
		value = 3;
	}

	public void spent(Pane p) {
		alive = false;
		p.getChildren().remove(this.c);
	}

}

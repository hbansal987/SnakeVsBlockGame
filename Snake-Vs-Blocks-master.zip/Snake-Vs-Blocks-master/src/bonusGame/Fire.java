package bonusGame;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;

public class Fire {
	ImageView c;
	double positionx;
	double positiony;
	int curr = 0;
	int flameframes = 100;
	boolean flameOn;
	boolean alive = true;

	public Fire(Path p2, Pane pane) {
		positionx = p2.centerX;
		positiony = p2.centerY;
		flameOn = true;
		
		Image fireImage = new Image("/bonusGame/fire.gif");
		c= new ImageView();
		c.setImage(fireImage);
		c.setFitHeight(100);
		c.setFitWidth(100);
		c.setX(p2.centerX -50);
		c.setY(p2.centerY - 50);
	}
	
	public void updateFire() {
		curr ++;
		if(curr  > flameframes) {
			curr = 0;
			switchFire();
		}
	}
	
	public void switchFire() {
		flameOn = !flameOn;
		if(flameOn) {
			c.setVisible(true);
		}else {
			c.setVisible(false);
		}
	}

//	public LinkedList<smolder> addSmolders(Pane p) {
//		// TODO Auto-generated method stub
//		for(int i = 0 ; i < 100 ; i ++) {
//			smolders.add(new smolder(this , positionx, positiony));
//			p.getChildren().add(smolders.getLast().c);
//		}
//		return smolders;
//	}

//	public void animateSmolders() {
//		// TODO Auto-generated method stub
//		for(smolder s : smolders) {
//			s.animate();
//		}
//		
//	}
}
